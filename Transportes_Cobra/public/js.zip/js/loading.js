function mostrarLoading() {
    $("#content-loading").removeClass("loading_hide");
    $("#content-loading").addClass("loading_show");
}
function ocultarLoading() {
    $("#content-loading").removeClass("loading_show");
    $("#content-loading").addClass("loading_hide");
}